"""
DeathModeV2_OrderFlow — NFI X7 + OrderFlow 필터 (전략2)

전략1(Base)에서 OrderFlow 필터만 추가:
- CVD(Cumulative Volume Delta): 매수압 > 매도압 시만 진입
- VWAP: 가격이 VWAP 위에 있을 때만 롱 진입
- Volume Spike: 평균 대비 1.5배 이상 거래량 확인
- ICT는 여전히 로깅만 (진입 차단 없음)
"""
import logging
import numpy as np
import pandas as pd
from datetime import datetime
from freqtrade.strategy import DecimalParameter, IntParameter
from pandas import DataFrame
from typing import Optional

import sys, os
sys.path.insert(0, os.path.dirname(__file__))
from DeathModeV2_Base import DeathModeV2_Base

log = logging.getLogger(__name__)


class DeathModeV2_OrderFlow(DeathModeV2_Base):
    """NFI X7 + ICT 로깅 + OrderFlow 필터"""

    INTERFACE_VERSION = 3

    def version(self) -> str:
        return "death-v2-orderflow-1.0"

    # ═══════════════════════════════════════
    # OrderFlow 파라미터
    # ═══════════════════════════════════════
    # CVD: 롤링 윈도우 (캔들 수)
    cvd_window    = IntParameter(5, 30, default=14, space="buy", optimize=False)
    # VWAP 윈도우
    vwap_window   = IntParameter(20, 200, default=96, space="buy", optimize=False)
    # 거래량 스파이크 배수
    vol_spike_mul = DecimalParameter(1.0, 3.0, default=1.5, space="buy", optimize=False)

    # ═══════════════════════════════════════
    # OrderFlow 지표 계산
    # ═══════════════════════════════════════
    def _calc_cvd(self, df: DataFrame) -> pd.Series:
        """
        단순 CVD 근사: (close-open)/range * volume 합산
        양수 = 매수압 우위
        """
        rng = (df["high"] - df["low"]).replace(0, np.nan)
        delta = ((df["close"] - df["open"]) / rng) * df["volume"]
        return delta.rolling(self.cvd_window.value).sum()

    def _calc_vwap(self, df: DataFrame) -> pd.Series:
        """
        Rolling VWAP (typical price 기준)
        """
        tp  = (df["high"] + df["low"] + df["close"]) / 3
        win = self.vwap_window.value
        return (tp * df["volume"]).rolling(win).sum() / df["volume"].rolling(win).sum()

    def _vol_spike(self, df: DataFrame) -> pd.Series:
        """거래량이 평균 대비 spike_mul 배 이상이면 True"""
        avg_vol = df["volume"].rolling(20).mean()
        return df["volume"] >= (avg_vol * self.vol_spike_mul.value)

    # ═══════════════════════════════════════
    # 지표 추가
    # ═══════════════════════════════════════
    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe = super().populate_indicators(dataframe, metadata)
        # OrderFlow 지표
        dataframe["of_cvd"]       = self._calc_cvd(dataframe)
        dataframe["of_vwap"]      = self._calc_vwap(dataframe)
        dataframe["of_vol_spike"] = self._vol_spike(dataframe)
        return dataframe

    # ═══════════════════════════════════════
    # 진입: NFI 신호 + OrderFlow 필터
    # ═══════════════════════════════════════
    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # 부모(Base) → NFI 원본 신호 획득
        dataframe = super().populate_entry_trend(dataframe, metadata)

        if "enter_long" in dataframe.columns:
            # OrderFlow 필터 조건 (Vol Spike 제외 — 병목 확인됨, 캔들의 7%만 통과)
            cvd_bull   = dataframe["of_cvd"] > 0                          # 매수압 우위
            above_vwap = dataframe["close"] > dataframe["of_vwap"]        # VWAP 위

            of_filter = cvd_bull & above_vwap

            # NFI 신호 & OrderFlow 필터 교집합
            dataframe.loc[~of_filter, "enter_long"] = 0

            # 로깅
            blocked = (dataframe["enter_long"] == 0) & (dataframe["enter_long"].shift(1) == 1)
            if blocked.any():
                log.debug(f"[OF-FILTER] {metadata['pair']} OrderFlow 필터로 {blocked.sum()}건 차단")

        return dataframe

    # ═══════════════════════════════════════
    # 진입 확인 + OrderFlow 로깅
    # ═══════════════════════════════════════
    def confirm_trade_entry(
        self,
        pair: str,
        order_type: str,
        amount: float,
        rate: float,
        time_in_force: str,
        current_time: datetime,
        entry_tag: Optional[str],
        side: str,
        **kwargs,
    ) -> bool:
        df, _ = self.dp.get_analyzed_dataframe(pair, self.timeframe)
        if len(df) >= 1:
            last = df.iloc[-1]
            kz   = last.get("ict_kill_zone", "?")
            fvg  = last.get("ict_fvg", "?")
            pd_p = last.get("ict_pd_pct", 0)
            cvd  = last.get("of_cvd", 0)
            vwap = last.get("of_vwap", 0)
            log.info(
                f"[OF-LOG] {pair} | tag={entry_tag} | KZ={kz} | FVG={fvg} | "
                f"PD={pd_p:.1f}% | CVD={cvd:.2f} | VWAP={vwap:.4f}"
            )
        return True  # 항상 진입 허용 (OrderFlow는 populate에서 이미 필터)
